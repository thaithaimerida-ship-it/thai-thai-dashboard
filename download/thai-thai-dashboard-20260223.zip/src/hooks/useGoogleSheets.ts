'use client';

import { useState, useEffect, useCallback } from 'react';

interface IngresoRow {
  Fecha: string;
  'Fuente / Cliente': string;
  Categoría: string;
  'Monto Bruto (+)': string;
  'Comisión / Retención (-)': string;
  'Monto Neto (Cálculo)': string;
  'Cuenta Destino': string;
  'Notas / UUID': string;
}

interface GastoRow {
  Fecha: string;
  Proveedor: string;
  RFC: string;
  Descripción: string;
  Cantidad: string;
  'P. Unitario': string;
  Descuento: string;
  Impuestos: string;
  Total: string;
  Categoría: string;
  'Grupo P&L': string;
  Origen: string;
  'Link de Factura': string;
  UUID: string;
  Procesado_En: string;
}

interface CorteCajaRow {
  Fecha: string;
  Turno: string;
  'Venta Neta': string;
  'Impuesto Total': string;
  'Venta con Imp.': string;
  Efectivo: string;
  Tarjeta: string;
  Otros: string;
  'Propinas Pagadas': string;
  'No. de Comensales': string;
  Validación: string;
  'Fondo Inicial': string;
  'Declaración Cajero Efectivo': string;
  'Efectivo Final': string;
}

interface SheetsResponse {
  sheet: string;
  headers: string[];
  totalRows: number;
  data: IngresoRow[] | GastoRow[] | CorteCajaRow[];
}

// Parsear valor monetario (ej: "$7,050.60" -> 7050.60)
export function parseMoney(value: string): number {
  if (!value) return 0;
  const cleaned = value.replace(/[$,\s]/g, '').replace(/[()]/g, '');
  const num = parseFloat(cleaned);
  return isNaN(num) ? 0 : num;
}

// Parsear fecha (ej: "1 enero, 2026" -> Date)
export function parseFecha(fechaStr: string): Date | null {
  if (!fechaStr) return null;
  
  const meses: Record<string, number> = {
    'enero': 0, 'febrero': 1, 'marzo': 2, 'abril': 3,
    'mayo': 4, 'junio': 5, 'julio': 6, 'agosto': 7,
    'septiembre': 8, 'octubre': 9, 'noviembre': 10, 'diciembre': 11
  };
  
  const match = fechaStr.match(/(\d+)\s+(\w+),?\s*(\d+)/i);
  if (match) {
    const dia = parseInt(match[1]);
    const mesNombre = match[2].toLowerCase();
    const año = parseInt(match[3]);
    const mes = meses[mesNombre];
    if (mes !== undefined) {
      return new Date(año, mes, dia);
    }
  }
  return null;
}

// Obtener mes/año de una fecha
export function getMesAnio(fecha: Date): string {
  const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  return `${meses[fecha.getMonth()]} ${fecha.getFullYear()}`;
}

export function useGoogleSheets() {
  const [ingresos, setIngresos] = useState<IngresoRow[]>([]);
  const [gastos, setGastos] = useState<GastoRow[]>([]);
  const [cortesCaja, setCortesCaja] = useState<CorteCajaRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    
    try {
      const [ingresosRes, gastosRes, cortesRes] = await Promise.all([
        fetch('/api/sheets?sheet=Ingresos_BD'),
        fetch('/api/sheets?sheet=Gastos_BD'),
        fetch('/api/sheets?sheet=Cortes_de_Caja')
      ]);

      if (!ingresosRes.ok || !gastosRes.ok) {
        throw new Error('Error al obtener datos de Google Sheets');
      }

      const ingresosData: SheetsResponse = await ingresosRes.json();
      const gastosData: SheetsResponse = await gastosRes.json();
      const cortesData: SheetsResponse = cortesRes.ok ? await cortesRes.json() : { data: [] };

      setIngresos(ingresosData.data as IngresoRow[]);
      setGastos(gastosData.data as GastoRow[]);
      setCortesCaja(cortesData.data as CorteCajaRow[]);
      setLastUpdate(new Date());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  return {
    ingresos,
    gastos,
    cortesCaja,
    loading,
    error,
    lastUpdate,
    refetch: fetchData
  };
}

// Procesar datos para el dashboard
export function procesarDatosDashboard(ingresos: IngresoRow[], gastos: GastoRow[], cortesCaja: CorteCajaRow[] = []) {
  // Agrupar por mes
  const datosPorMes: Record<string, {
    ventasBrutas: number;
    comisiones: number;
    ventasNetas: number;
    gastos: number;
    comensales: number;
    ingresos: IngresoRow[];
    gastosDetalle: GastoRow[];
  }> = {};

  // Procesar comensales desde Cortes_de_Caja
  const comensalesPorMes: Record<string, number> = {};
  cortesCaja.forEach(corte => {
    const fecha = parseFecha(corte.Fecha);
    if (!fecha) return;
    const mesKey = getMesAnio(fecha);
    const comensales = parseInt(corte['No. de Comensales']) || 0;
    comensalesPorMes[mesKey] = (comensalesPorMes[mesKey] || 0) + comensales;
  });

  // Procesar ingresos
  ingresos.forEach(ing => {
    const fecha = parseFecha(ing.Fecha);
    if (!fecha) return;
    
    const mesKey = getMesAnio(fecha);
    if (!datosPorMes[mesKey]) {
      datosPorMes[mesKey] = {
        ventasBrutas: 0, comisiones: 0, ventasNetas: 0, gastos: 0, comensales: 0,
        ingresos: [], gastosDetalle: []
      };
    }
    
    const bruto = parseMoney(ing['Monto Bruto (+)']);
    const comision = parseMoney(ing['Comisión / Retención (-)']);
    const neto = parseMoney(ing['Monto Neto (Cálculo)']);
    
    datosPorMes[mesKey].ventasBrutas += bruto;
    datosPorMes[mesKey].comisiones += comision;
    datosPorMes[mesKey].ventasNetas += neto;
    datosPorMes[mesKey].ingresos.push(ing);
  });

  // Procesar gastos - SOLO incluir: Costo de Venta y Gastos Operativos (según Grupo P&L)
  // También trackear Impuestos y Financiamientos para Cash Yield
  const impuestosFinanciamientosPorMes: Record<string, number> = {};
  
  gastos.forEach(gas => {
    const fecha = parseFecha(gas.Fecha);
    if (!fecha) return;
    
    const mesKey = getMesAnio(fecha);
    const grupoPL = gas['Grupo P&L'] || '';
    const categoria = gas.Categoría || '';
    
    // Trackear Impuestos y Financiamientos (para Cash Yield)
    if (categoria === 'Impuestos Sat' || categoria === 'Prestamo BBVA') {
      const total = Math.abs(parseMoney(gas.Total));
      impuestosFinanciamientosPorMes[mesKey] = (impuestosFinanciamientosPorMes[mesKey] || 0) + total;
      return; // No incluir en gastos operativos
    }
    
    // Solo incluir gastos operativos del negocio (basado en Grupo P&L)
    if (grupoPL !== 'Costo de Venta' && grupoPL !== 'Gastos Operativos') return;
    
    if (!datosPorMes[mesKey]) {
      datosPorMes[mesKey] = {
        ventasBrutas: 0, comisiones: 0, ventasNetas: 0, gastos: 0, comensales: 0,
        ingresos: [], gastosDetalle: []
      };
    }
    
    const total = Math.abs(parseMoney(gas.Total));
    datosPorMes[mesKey].gastos += total;
    datosPorMes[mesKey].gastosDetalle.push(gas);
  });

  // Agregar comensales a cada mes
  Object.keys(comensalesPorMes).forEach(mesKey => {
    if (datosPorMes[mesKey]) {
      datosPorMes[mesKey].comensales = comensalesPorMes[mesKey];
    }
  });

  // Calcular KPIs por mes
  const mesesOrdenados = Object.keys(datosPorMes).sort((a, b) => {
    const [mesA, añoA] = a.split(' ');
    const [mesB, añoB] = b.split(' ');
    const meses = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
                   'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
    return (parseInt(añoA) * 12 + meses.indexOf(mesA)) - (parseInt(añoB) * 12 + meses.indexOf(mesB));
  });

  const ventasMensuales = mesesOrdenados.map(mes => {
    const datos = datosPorMes[mes];
    const utilidadBruta = datos.ventasNetas - datos.gastos;
    const impuestosFin = impuestosFinanciamientosPorMes[mes] || 0;
    const utilidadNeta = utilidadBruta - impuestosFin;
    const margenBruto = datos.ventasNetas > 0 ? Math.round((utilidadBruta / datos.ventasNetas) * 100) : 0;
    const cashYield = datos.ventasNetas > 0 ? (utilidadNeta / datos.ventasNetas) * 100 : 0;
    const comensales = datos.comensales || comensalesPorMes[mes] || 0;
    
    return {
      mes: mes.split(' ')[0].substring(0, 3),
      mesCompleto: mes,
      ventas: datos.ventasNetas,
      ventasBrutas: datos.ventasBrutas,
      comisiones: datos.comisiones,
      gastos: datos.gastos,
      utilidad: utilidadBruta,
      utilidadNeta,
      impuestosFinanciamientos: impuestosFin,
      margenBruto,
      margenNeto: margenBruto,
      cashYield: Math.round(cashYield * 100) / 100, // 2 decimales
      cashYieldMonto: utilidadNeta,
      indiceVsPE: datos.ventasNetas / 295000, // PE_MENSUAL = $295,000
      comensales,
    };
  });

  // Totales acumulados
  const acumulado = {
    ventasBrutas: ventasMensuales.reduce((sum, m) => sum + m.ventasBrutas, 0),
    comisiones: ventasMensuales.reduce((sum, m) => sum + m.comisiones, 0),
    ventasNetas: ventasMensuales.reduce((sum, m) => sum + m.ventas, 0),
    gastos: ventasMensuales.reduce((sum, m) => sum + m.gastos, 0),
    comensales: ventasMensuales.reduce((sum, m) => sum + m.comensales, 0),
  };
  acumulado.utilidad = acumulado.ventasNetas - acumulado.gastos;

  // Comisiones por plataforma
  const comisionesPorPlataforma: Record<string, { bruto: number; comision: number; neto: number; count: number }> = {};
  ingresos.forEach(ing => {
    const plataforma = ing['Fuente / Cliente'] || 'Otros';
    if (!comisionesPorPlataforma[plataforma]) {
      comisionesPorPlataforma[plataforma] = { bruto: 0, comision: 0, neto: 0, count: 0 };
    }
    comisionesPorPlataforma[plataforma].bruto += parseMoney(ing['Monto Bruto (+)']);
    comisionesPorPlataforma[plataforma].comision += parseMoney(ing['Comisión / Retención (-)']);
    comisionesPorPlataforma[plataforma].neto += parseMoney(ing['Monto Neto (Cálculo)']);
    comisionesPorPlataforma[plataforma].count++;
  });

  // Gastos por categoría
  const gastosPorCategoria: Record<string, number> = {};
  gastos.forEach(gas => {
    const categoria = gas['Grupo P&L'] || gas.Categoría || 'Otros';
    const total = Math.abs(parseMoney(gas.Total));
    gastosPorCategoria[categoria] = (gastosPorCategoria[categoria] || 0) + total;
  });

  return {
    ventasMensuales,
    acumulado,
    comisionesPorPlataforma,
    gastosPorCategoria,
    datosPorMes
  };
}
